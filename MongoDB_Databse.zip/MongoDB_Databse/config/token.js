//create the json object
let obj = {
    "token":""
};
module.exports = obj;